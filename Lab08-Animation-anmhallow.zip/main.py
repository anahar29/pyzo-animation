## 
# Import the program you want to run
#
# Copy over your Lab 5 code into the Lab8.py file 
##

#import AnimationDemo.py
import Lab8.py