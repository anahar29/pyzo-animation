# Lab8: Animation

Read Chapter 8 and take the quiz.  Repeat until you get perfect on the quiz.  Worksheet does not need to be done (but good exercise for testing your knowledge).

For this lab you will do the following:

1. Reuse the code from Lab5 (copy it here)
   
2. Add animation to your scene
   * At least 3 separately moving items
   * Movement in multiple directions
   * You can add objects to you scene to move around but it must make sense to the context of the scene
   * Add changes of direction based on conditions (edge of screen for example)
   * The snow effect is cool but everyone does that, come up with something original ;-)

Remember to read the requirements of the lab and any additional give to you in class.  There will be marks for creativity so make sure to come up with unique parts of your scene.

You can use Pyzo or this Repl.it to work on your implementation but you will hand-in your final implementation here.  You will also indicate in the Google Classroom assignment, when it is done.