##
# Animation demo
#
# @author Mr. Reid
# @course ICS3UC
# @date 2020/12/18
#
# Pygame base template for opening a window - MVC version
# Simpson College Computer Science
# http://programarcadegames.com/
##

## Pygame setup
import pygame
pygame.init()
size = (400, 400)
screen = pygame.display.set_mode(size)
pygame.display.set_caption("My Animation")

## MODEL - Data use in system
# Define some colors
BLACK = (0, 0, 0)
WHITE = (255, 255, 255)
GREEN = (0, 255, 0)
RED = (255, 0, 0)
BLUE = (0, 0, 255)

triColour = [0,255,0]
moonX = 100

# Loop until the user clicks the close button.
done = False

# Used to manage how fast the screen updates
clock = pygame.time.Clock()

## Main Program Loop
while not done:
    ## CONTROL
    # Check for events
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            done = True

    # Game logic    
    if (moonX < 400):
        moonX = moonX + 1
    elif (moonX >= 400):
        moonX = -100

    triColour[1] = triColour[1] - 1
    if triColour[1] < 0:
        triColour[1] = 255
        
    ## VIEW
    # Clear screen
    screen.fill(BLACK)

    # Draw
    pygame.draw.ellipse(screen, WHITE, [100, moonX, 100, 100], 0)
    pygame.draw.polygon(screen, triColour, [[200, 300],[300,300],[250,250]] ,0)

    # Update Screen
    pygame.display.flip()
    clock.tick(40)

# Close the window and quit
pygame.quit()